//
//	George O'Neill @ University of York, 2020/02/12
//
//	This file holds methods for gates, except they actually are all short enough for the header
//
#include "../include/gates.h"

namespace fnt {	//	create unique working area

}	//	end namespace fnt



void gates(){};	//	allow root compilation